<?php


return [
    'saveNotificationText' => 'Wishlist Stored Successfully!',
    'destroyNotificationText' => 'Wishlist Remove Successfully!',
];
