<?php


return [
    'notificationText' => 'Review Stored Successfully!',
    'review-list' => "Reviews",
    'review-product' => "Reviews",
    'product-tab' => 'Review',
    'title' => 'Product Review'
];
