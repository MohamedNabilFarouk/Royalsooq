AvoRed.initialize((Vue) => {
    Vue.component('catalog-review', require('../components/CatalogReview.vue').default)  
})
