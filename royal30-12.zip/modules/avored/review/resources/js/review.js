AvoRed.initialize((Vue) => {
    Vue.component('a-review', require('../components/Review.vue').default)  
})
