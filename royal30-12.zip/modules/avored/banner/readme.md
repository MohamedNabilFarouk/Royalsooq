# AvoRed Banner Module

### Installation

    composer require avored/banner 
    
    php artisan migrate

### How to Use