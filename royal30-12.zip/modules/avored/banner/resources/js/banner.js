AvoRed.initialize((Vue) => {
    Vue.component('banner-table', require('../components/BannerTable.vue').default)    
    Vue.component('banner-edit', require('../components/BannerEdit.vue').default)    
})
