<?php

return [
    'title' => 'Banner',
    'name' => 'Name',
    'image' => 'Image',
    'alt_text' => 'Alt Text',
    'normal' => 'Normal',
    'new_tab' => 'New Tab',
    'url' => 'Url',
    'target' => 'Target',
    'status' => 'Status',
    'sort_order' => 'Sort Order',
    'index' => [
        'title' => 'Banner List'
    ],
    'edit' => [
        'title' => 'Banner Save'
    ]
];
