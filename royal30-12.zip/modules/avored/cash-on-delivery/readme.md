# AvoRed Cash On Delivery Payment Module

### Installation

    composer require avored/cash-on-delivery 
    
    php artisan migrate

### How to Use
