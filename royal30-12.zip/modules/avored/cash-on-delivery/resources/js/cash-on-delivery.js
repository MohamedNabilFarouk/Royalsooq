AvoRed.initialize((Vue) => {
    Vue.component('avored-cash-on-delivery', require('../components/AvoRedCashOnDelivery.vue').default)
    Vue.component('cash-on-delivery-config', require('../components/CashOnDeliveryConfig.vue').default)
})
