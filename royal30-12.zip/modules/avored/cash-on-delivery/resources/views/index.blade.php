<avored-cash-on-delivery>
</avored-cash-on-delivery>
@push('scripts')
<script src="{{ asset('avored-admin/js/cash-on-delivery.js') }}"></script>
@endpush
