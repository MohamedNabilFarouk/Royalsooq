<?php

return [
    'config-title' => 'Cash On Delivery',
    'enabled' => 'Enabled',
    'disabled' => 'Disabled',
    'status' => 'Status'
];
