<?php

return [
    'feature'=>'الاعلانات المميزة',
    'latest'=>'الاعلانات المضافة حديثا',
    'weakly'=>'الاعلانات الممولة الاسبوعية',
    'new_arrival'=>'الاحدث',
    'best'=>'الاعلي تقيما',
    'on_sale'=>'الخصومات',
    'f_service'=>'الخدمات المميزة',
    'n_service'=>'الخدمات الجديدة',
    'shops'=>'المتجر',
    'shop_info'=>'معلومات عن متجرك',
    'your_shops'=>"متجرك",
    'services'=>'الخدمات',
    'free_ad'=>'اضف اعلانك مجانا',
    'call'=>'اتصل',
    'chat'=>'مراسلة',
    'all_cat'=>'كل الاقسام',
    'search'=>'ابحث عن',
    'privacy'=>'سياسة الخصوصية',
    'term_of_use'=>'شروط الاستخدام',
    'freeAds'=>'الاعلانات المجانية',
    'contact_us'=>'تواصل معنا',
    'news'=>'اشترك ليصلك كل جديد',
    'questetions'=>'للاستعلام تواصل معنا !  24/7 ',
    'address'=>'العنوان',
    //login and register

    'email'=>'البريد الالكتروني',
    'password'=>'كلمة المرور',
    'name'=>'الاسم',
    'pass_confirmition'=>'تاكيد كلمه المرور',
    'show_pass'=>'اظهر كلمة المرور',
    'register_seller'=>'التسجيل كبائع',
    'sign_up'=>'مستخدم جديد',
    'already_member'=>'لدي حساب',
    'log_in'=>'تسجيل الدخول ',
    'agree'=>'الموافقة علي الشروط',   
    'reg_slogan'=>'انضم الينا',
    'hello'=>'مرحبا بك !', 
    'login_slogan'=>'سجل الان و اضف اعلانك',
    "connect_with"=>'او سجل بواسطة',
    //product-details

    'home'=>'الرئيسية',
    'contact_with_seller'=>'تواصل مع البائع',
    'seller_map'=>'خريطه البائع',
    'related_products'=>' اعلانات ذات صلة',
    'des'=>'اوصف اعلانك',
    'contact_info'=>'معلومات التواصل',
    'vid'=>'الفيديو',
    'review'=>'التقييم',
    'posted_by'=>'نشر بواسطة',
    'views'=>'مشاهدات',
    'safety'=>'حفاظا علي سلامتك',
    'meet'=>'مقابلة البائع في مكان عام',
    'check'=>'افحص المنتج قبل الشراء',
    'pay'=>' ادفع عند حصولك علي المنتج',
    'appear_phone'=>'اظهر رقم المعلن',

     // account
     'account'=>'الحساب',
     'profile'=>'الصفحة الشخصية',
     'file_upload'=>'اضف صورة شخصية',
     'select_drag'=>'اختر صورة او اسحبها هنا',
     'last_login'=>'اخر ظهور في',
     'select_file'=>'اختر',
     'save'=>'حفظ',
     'delete_image'=>'حذف الصورة',
     'setting'=>'الاعدادات',
     'change_pass'=>'تغيير كلمة المرور',
     'current_pass'=>'كلمه المرور الحالية',
     'new_pass'=>'كلمة المرور الجديدة',
     'confirm_new_pass'=>'تاكيد كلمة المرور',
     'ads'=>'اعلانات',
     'fav'=>'مفضلة',
     'mails'=>'رسائل',
     'shop_info'=>'معلومات عن متجرك',
    'shop_about' =>'عن المتجر',


     //account side Nav
    
    'my_acc'=>'حسابي',
    'personal'=>'الصفحة الشخصية',
    'my_ads'=>'اعلاناتي',
    'favorite_ads'=>'المفضلة',
    'saved_search'=>'البحث المحفوظ',
    'pending'=>'الاعلانات المعلقة',
    'addresses'=>'العنوان',
    'orders'=>'الطلبات',
    'complaint'=>'الشكوي',
    'logout'=>'تسجيل الخروج',
    'soon'=>'قريبا',
    'visit'=>'مشاهدة',

    //user free Ads
    'price'=>'السعر',
    'action'=>'الحدث',
    'edit'=>'تعديل',
    'delete'=>'حذف',
    'add'=>'اضافة اعلان جديد',
    'image'=>'الصورة',
    'approval'=>'الموافقة',
    'approved'=>'تم الموافقة',
    'pending'=>'معلق',

    'attributes'=>'المميزات',
    'model'=>'الموديل',
    'year'=>'السنة',
    'color'=>'اللون',
    'manual'=>"يدوي",
    'auto'=>'اوتوماتيك',
    'condition'=>'الحالة',
    'payment'=>'طريقة الدفع',
    'kilos'=>'الكيلومترات',
    'car'=>'السيارة',
    'installments'=>'تقسيط',
    'cash'=>'كاش',
    'new'=>'جديد',
    'used'=>'مستعمل',

    'job_type'=>'نوع الاعلان',
    'employer'=>'صاحب عمل ',
    'seeker'=>'باحث عن عمل',


    //complaint
 'send'=>'ارسل',
 'or'=>'او',
 'suggestion'=>'اقتراحك',
 'phone'=>'التليفون',
 'subject'=>'الموضوع',
 'message'=>'الرسالة',


 //add free ads
 'free_ad_page'=>'اضف اعلانك',
 'free'=>'مجانا',
 'title'=>'الاسم',
 'product'=>'المنتج',
 'category'=>'صنف اعلانك',
 'sub'=>'التصنيف الفرعي',
 'city'=>'المكان',
 'price'=>'السعر',
 'photos'=>'الصور',
 'more_image'=>'يمكنك اختيار اكثر من صورة',
 'vid_link'=>'رابط الفيديو',
 'map_view'=>'المنتج علي الخريطة',
 'map_frame'=>'اضف فريم الخريطة',
 'add'=>'اضافة',
 'ad_position'=>'اختر مكان الاعلان ',
 'select'=>'اختر',
 'area'=>'المساحة',
 'room'=>'عدد الغرف',
 'bathroom'=>'عدد الحمامات',
 'fur'=>'مفروش',
 'unfur'=>'غير مفروش',
 'transmission'=>'ناقل الحركة',
 'warranty'=>'الضمان',
 'yes'=>'نعم',
 'no'=>'لا',
 'negotiable'=>'قابل للتفاوض',
'preview'=>'مشاهدة',
'log_first'=>'برجاء التسجيل اولا ',
 //shops


'verfied'=>'موثق',
'member_since'=>'عضو منذ',
'add_favorite'=>'اضف الي المفضلة',
 

//search
's_product_feature'=>'ابحث بخصائص المنتج',
's_price'=>'ابحث بالسعر',
's_cat'=>'ابحث بالقسم',
's_city'=>'ابحث بالمدينة',
'search_btn'=>'بحث',
's_new'=>'جديد',
's_onsale'=>'في الخصم',
's_rated'=>'الاعلي تقييما',
's_from'=>'من',
's_to'=>'الي',
'sort'=>'رتب حسب',
'sort_price_desc'=>'من الاعلي الي الاقل',
'sort_price_asc'=>'من الاقل الي الاعلي ',
'sort_latest'=>'الاحدث',
'sort_oldest'=>'الاقدم',
//all categories

'freead_cat'=>'اقسام الاعلانات المجانية',
'sponsored_cat'=>'اقسام الاعلانات الممولة ',
'services_cat'=>'اقسام الخدمات ',
'view_all'=>'الكل',

//inbox
'show'=>'تفاصيل و ارسل رد',
'item'=>'الاعلان',
'at'=>'التوقيت',
'inbox'=>'الرسائل',
'reply'=>'الرد',

//language modal
'Regional Settings'=>'الاعدادات',
'Choose language'=>'اختر اللغة',
'choose country'=>'اختر الدولة',

//addresses
'addresses'=>'العناوين',
'shipping'=>'الشحن',
'options'=>'خيارات',

//chat

'send_to_seller'=>'ارسل رسالة للمعلن',
'no_item'=>'لا توجد نتائج للبحث',


'no_image'=> 'لا توجد صورة',
'welcome'=>'مرحبا',

//reset pass
'forget'=>'نسيت كلمة المرور ؟',
'Reset_Password'=>'استرجاع كلمة المرور',
'send_link'=>'ارسل رابط الاسترجاع',

//email verification
'verify'=>'تحقق من عنوان بريدك الإلكتروني',
'message'=>'قبل المتابعة ، يرجى التحقق من بريدك الإلكتروني للحصول على رابط التحقق. إذا لم تتلق البريد الإلكتروني ،',
'click'=>'انقر هنا لطلب آخر',
'check_mail'=>'تم إرسال رابط تحقق جديد إلى عنوان بريدك الإلكتروني.',
//success

'success'=>'تم اضافة الاعلان بنجاح',
'more_ads'=>'المزيد',
'allAds'=>'كل الاعلانات',
'phone_placeholder'=>'اترك رقم التليفون هنا',
];