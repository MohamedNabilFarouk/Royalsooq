

var AvoRed = (function() {
    return {
        initialize: function(callback) {
            callback(Vue)
        }
    };
})();


exports = module.exports = AvoRed;
