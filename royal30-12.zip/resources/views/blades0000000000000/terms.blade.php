@extends('layouts.app')
@section('content')
<div class="container">
	<div class="row">
		<h1>Terms of Use</h1>
		<br /><br />
		
		<h4>Term Of Use Welcome to RoyalSooq“RoyalSooq.com”:</h4>
		<p>RoyalSooq.com is a leading classifieds portal the websiteoffers great opportunityto  the sellers  to  advertise  and  post  their  products  and  services  under  a  large number of categories and sub-categories,to make the reach to their customers (buyers)  easier, The  user  (buyer) search or  adviser(seller)  can  use  all  website categories to buy or sell through it , andthe users(buyers) cancontact sellers to buy the listed products or servicesfreely. These Terms of Use sets the terms of the  agreement  between  you and RoyalSooq. And It  governs  your  use  of  the products  and  services  we  offer  through  our RoyalSooqwebsite  and associated applications.</p>
        <br></br>
        <h4>Use of the Royal Sooq website:</h4>
        <br>
		<p>You  can  use  the  site  and  publish  to  any  of  the  existing  sections,  taking  into account  that  the  following  prohibitions  are  avoided</p>
        
        
		
		
		
			<br /><br />
		<h4>The advertisement  will be  deleted  and  the  site  reserves  the  right  to  permanently  delete  the user’s  account,  put  it  on  the  blacklist  or  inform  the  competent authorities to implement the necessary law:</h4>
        <br>
        <li>Violation of any of the laws or any point of the prohibitedcontent policy of Royal Sooq</li>
        <li>Violation of any of the rights of any other party, or publishing any harmful mail, chain letters, or hierarchical marketing scheme.</li>
        <li>Use any prohibited means to gain access to the site’s database and collect content   for   any   purpose,   including   bots,   web   spiders,   and   similar </li> 
        
        <li>Posting false or misleading ads or trying to copy, modify or post someone else’s content.</li>
        <li>Collect information about other users, including private email or any other personal information.</li>
        <li>Misuse of the site by spreading viruses or any other technology that may harm the site or the interests and property of users or anyone </li>  
        
        <li>Attempting to harm the site or carry out any sabotage, such as attempts to block the service or impose an illogical burden on the infrastructure of the site</li>
        <li>Override the procedures used to prevent or restrict access to the site</li>
        <li>Use   personal   information   about   other   people   without   their   explicit consent. </li>   

        <li>Sale of natural or artificial human organs, including blood and body fluids as well</li>
        <li>Antiquities  or  treasures  that  are  not  allowed  to  be  traded  under  any applicable law.</li>
        <li>Counterfeit or stolen goods or illegal and authorized services.</li>   


        <li>Selecting the wrong departments and sub-divisions, such as advertising a car in the real estate division.</li>
        <li>To  publish  ads  for  competing  sites  or  companies  for  the  Royal  Sooqwebsite</li>
        <li>Weapons  and  related  items  (such  as:  firearms,  ammunition,  tear  gas, rifles, and sharp objects). </li>   

        <li>Advertisements for loans, financing and commercial facilitation companies.</li>
        <li>Post ads with redirect links to other sites</li>
        <li>Posting scams and fake ads.</li>   
        <br /><br />
		
		
			<br /><br />
		<h4>Important note:</h4><br>
		        The Royal Sooqsite is not responsible for the sale and purchase that takes place outside the site between advertisers, as the site is only a mediator between the seller and the buyer to display free classified ads
            
            <h4>Therefore,  you  must  consider  the  following  things  whenbuying  and selling:</h4>
            <li>Do  not  deliver  any  money  before  obtaining  the  service  provided  by  the seller.</li>
            <li>Previewing the product before purchasing and ensuring its safety and that there are no defects in it..</li>
            <li>Confirm the meeting place to deliver or receive the product and choose a public place.</li>
            <li>Use safe payment methods to avoid fraud.</li>
            <br>
            <h4>Personal information: When you use the Royal Souq website, you agree to collect, transfer, store and use your personal information on various other sites by the site</h4>
    <h6>Fees  and Services:</h6><p>In  general,  advertising  on  the  Royal  Sooq  site  is  free  of charge,however we charge fees for some of the services we provide to users. In the event that you use one of the services for which we charge fees, you will be required  to  review  and  approve  them,  and  payment  is  made  either  in  local currency or in US dollars, and we may change this mechanism from time to time, and in turn we inform you of any change to the payment policy by posting it on the  site,  and  you  may  We  choose  some  changes  to  the  form  of  payment temporarily  when  posting  promotions  or  new  services.  On  theother  hand,  this fee  is  not  refundable  and  you  have  to  pay  it,  and  if  you  do  not  do  so  we  will cancel the validity of the service you used.</p>
           
<br>
<h4>Violation of conditions and compensation:</h4>
<p>We kindly ask you to inform us of any violations of the terms that you become aware  of  by  contacting  us  using  the  means  of  communication  located  at  the bottom  of  the  home  page  on  RoyalSooq.com.  Any refrainto  act  by  the  Royal Sooq website regardingto a breach by you or by others does not meanwaiver of the site’s rightto respond in relation to subsequent or similar violations by you or by others. Regardless of the above mentioned terms and in relation to any other condition of these conditions, the Royal Sooq website administration reserves the right to seek legal and fair compensation, including but not limited to the specific performance  of  any  condition  contained  in  these  terms,  a  preliminary  judicial order or Permanent, against breach or threatof breach of any condition, without the necessity to publish the bond</p>
<br><br>
<h4>Royal  Sooq  Website  includes  an  English  version  of  the  Terms  of Use, however  the  Arabic  version  is  only  approved  and  is  the  primary reference.</h4>
</div>
		
        </div>
        
        @stop