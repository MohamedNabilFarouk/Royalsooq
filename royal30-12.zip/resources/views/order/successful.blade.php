@extends('layouts.app')

@section('content')
    <h1>{{ __('Order Placed Successfully') }}</h1>
@endsection
