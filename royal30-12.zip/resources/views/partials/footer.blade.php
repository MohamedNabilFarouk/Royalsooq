<a-layout-footer style="text-align: center">
    AvoRed  &copy;{{ date('Y') }} created by AvoRed 
</a-layout-footer>
