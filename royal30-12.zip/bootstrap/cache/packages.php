<?php return array (
  'avored/framework' => 
  array (
    'providers' => 
    array (
      0 => 'AvoRed\\Framework\\AvoRedProvider',
    ),
    'aliases' => 
    array (
      'Breadcrumb' => 'AvoRed\\Framework\\Support\\Facades\\Breadcrumb',
      'Cart' => 'AvoRed\\Framework\\Support\\Facades\\Cart',
      'Menu' => 'AvoRed\\Framework\\Support\\Facades\\Menu',
      'Module' => 'AvoRed\\Framework\\Support\\Facades\\Module',
      'Payment' => 'AvoRed\\Framework\\Support\\Facades\\Payment',
      'Permission' => 'AvoRed\\Framework\\Support\\Facades\\Permission',
      'Shipping' => 'AvoRed\\Framework\\Support\\Facades\\Shipping',
      'Tab' => 'AvoRed\\Framework\\Support\\Facades\\Tab',
      'Widget' => 'AvoRed\\Framework\\Support\\Facades\\Widget',
    ),
  ),
  'awssat/laravel-visits' => 
  array (
    'providers' => 
    array (
      0 => 'Awssat\\Visits\\VisitsServiceProvider',
    ),
    'aliases' => 
    array (
      'Visits' => 'Awssat\\Visits\\Visits',
    ),
  ),
  'barryvdh/laravel-dompdf' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\DomPDF\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'PDF' => 'Barryvdh\\DomPDF\\Facade',
    ),
  ),
  'beyondcode/laravel-dump-server' => 
  array (
    'providers' => 
    array (
      0 => 'BeyondCode\\DumpServer\\DumpServerServiceProvider',
    ),
  ),
  'consoletvs/charts' => 
  array (
    'providers' => 
    array (
      0 => 'ConsoleTVs\\Charts\\ChartsServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/passport' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Passport\\PassportServiceProvider',
    ),
  ),
  'laravel/socialite' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Socialite\\SocialiteServiceProvider',
    ),
    'aliases' => 
    array (
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'mcamara/laravel-localization' => 
  array (
    'providers' => 
    array (
      0 => 'Mcamara\\LaravelLocalization\\LaravelLocalizationServiceProvider',
    ),
    'aliases' => 
    array (
      'LaravelLocalization' => 'Mcamara\\LaravelLocalization\\Facades\\LaravelLocalization',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'rebing/graphql-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Rebing\\GraphQL\\GraphQLServiceProvider',
    ),
    'aliases' => 
    array (
      'GraphQL' => 'Rebing\\GraphQL\\Support\\Facades\\GraphQL',
    ),
  ),
  'spatie/laravel-referer' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Referer\\RefererServiceProvider',
    ),
  ),
  'spatie/laravel-view-models' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\ViewModels\\Providers\\ViewModelsServiceProvider',
    ),
  ),
  'torann/geoip' => 
  array (
    'providers' => 
    array (
      0 => 'Torann\\GeoIP\\GeoIPServiceProvider',
    ),
    'aliases' => 
    array (
      'GeoIP' => 'Torann\\GeoIP\\Facades\\GeoIP',
    ),
  ),
  'willvincent/laravel-rateable' => 
  array (
    'providers' => 
    array (
      0 => 'willvincent\\Rateable\\RateableServiceProvider',
    ),
  ),
  'zgabievi/promocodes' => 
  array (
    'providers' => 
    array (
      0 => 'Gabievi\\Promocodes\\PromocodesServiceProvider',
    ),
    'aliases' => 
    array (
      'Promocodes' => 'Gabievi\\Promocodes\\Facades\\Promocodes',
    ),
  ),
);